=== Fixture Plugin ===
Stable tag: 1.2.0
