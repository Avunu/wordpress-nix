<?php
// Fixture theme functions.
